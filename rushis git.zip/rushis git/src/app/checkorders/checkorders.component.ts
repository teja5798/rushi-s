import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-checkorders',
  templateUrl: './checkorders.component.html',
  styleUrls: ['./checkorders.component.css']
})
export class CheckordersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
