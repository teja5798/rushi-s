import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BillingComponent } from './billing/billing.component';
import { PromosComponent } from './promos/promos.component';
import { HttpClient } from '../../node_modules/@types/selenium-webdriver/http';
import { FormsModule } from '@angular/forms';
import {   HttpClientModule } from '@angular/common/http';
import { OrderplacingComponent } from './orderplacing/orderplacing.component';
import { CheckordersComponent } from './checkorders/checkorders.component';
import { PaymentComponent } from './payment/payment.component';

@NgModule({
  declarations: [
    AppComponent,
    BillingComponent,
    PromosComponent,
    OrderplacingComponent,
    CheckordersComponent,
    PaymentComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
