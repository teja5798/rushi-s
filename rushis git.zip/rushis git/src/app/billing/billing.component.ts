import { Component, OnInit } from '@angular/core';
import {ServiceService} from '../service.service'
@Component({
  selector: 'app-billing',
  templateUrl: './billing.component.html',
  styleUrls: ['./billing.component.css']
})
export class BillingComponent implements OnInit {

  Placingorder:any

  constructor(private service:ServiceService) { 

     this.service.BillingDetails().subscribe(data =>{

      this.Placingorder=data
     });
}

  ngOnInit() {
  }

}
